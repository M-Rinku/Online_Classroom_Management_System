﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    

   

   

    protected void Button1_Click1(object sender, EventArgs e)
    {
        DataSet ds = server.getAllData("select * from course_details");
        int flag = ds.Tables[0].Rows.Count;
        for(int i=0;i<flag;i++)
        {
            int id = Int32.Parse(ds.Tables[0].Rows[i]["course_id"].ToString());
            string code = ds.Tables[0].Rows[i]["subject_code"].ToString();
            string final = code.Replace('-', ' ');
            server.InsertUpdateDelete("update course_details set subject_code='" + final + "'where course_id=" + id + "");
        }
    }
}