﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Net;
using System.Collections.Specialized;

/// <summary>
/// Summary description for clsuser
/// </summary>
public class sms
{

    public String api = "NmE0OTU3NDI0YzZhNmEzNDRhMzQ3ODMyNGIzNDZmNGY=";
    public String sender = "ARRKTM";
    public String number
    {
        get;
        set;
    }
    public String massage
    {
        get;
        set;
    }
    //https://api.textlocal.in/send/?apikey=akgVBNSO3U0-pDqDPnbykFyRXJHlTSl3dHIMs1X0qf&sender=OSHBBS&numbers=917602307242&message=
    public string sendSMS()
    {
        String message = HttpUtility.UrlEncode(massage);
        using (var wb = new WebClient())
        {
            byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , api},
                {"numbers" , number},
                {"message" , message},
                {"sender" , sender},
                {"test" , "false"}
                });
            string result = System.Text.Encoding.UTF8.GetString(response);
            return result;
        }
    }

}

