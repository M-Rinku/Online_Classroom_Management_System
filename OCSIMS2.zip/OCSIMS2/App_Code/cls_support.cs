﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for support
/// </summary>
public class cls_support
{
    public String name
    {
        get;
        set;
    }
    public Int64 mobile
    {
        get;
        set;
    }
    public String email
    {
        get;
        set;
    }
    public String query
    {
        get;
        set;
    }
    public String to_id
    {
        get;
        set;
    }
    public String status
    {
        get;
        set;
    }
    public String query_id
    {
        get;
        set;
    }
    public DataSet retrievequeries()
    {
        DataSet ds = server.getAllData("select * from tbl_query where to_id=" + to_id + " order by date");
        return ds;
    }
    public void deletequery()
    {
        server.InsertUpdateDelete("delete from tbl_query where query_id=" + query_id + "");
    }
    
}