﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clscontactus
/// </summary>
public class clscontactus
{
    public String name
    {
        get;
        set;
    }
    public Int64 mobile
    {
        get;
        set;
    }
    public String email
    {
        get;
        set;
    }
    public String query
    {
        get;
        set;
    }
    public String to_id
    {
        get;
        set;
    }
    public String status
    {
        get;
        set;
    }
    public String date
    {
        get;
        set;
    }
    public int submitquery()
    {
        int result = server.InsertUpdateDelete("insert into tbl_query values('" + name + "'," + mobile + ",'" + email + "','" + query + "','" + date + "'," + to_id + ",'" + status + "')");
        if(result==0)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}