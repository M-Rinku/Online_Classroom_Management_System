﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

/// <summary>
/// Summary description for clsmail
/// </summary>
public class clsmail
{
    public string to
    {
        get;
        set;
    }
    public string Message
    {
        get;
        set;
    }
    public void send()
    {
        SmtpClient client = new SmtpClient("Smtp.gmail.com", 587);
        client.EnableSsl = true;
        client.Credentials = new NetworkCredential("lowvocal7602@gmail.com", "7602307242");
        MailMessage msgobj = new MailMessage();
        msgobj.To.Add(to);
        msgobj.From = new MailAddress("lowvocal7602@gmail.com");
        msgobj.Subject = "Your Id Password";
        msgobj.Body = Message;
        client.Send(msgobj);
    }
}