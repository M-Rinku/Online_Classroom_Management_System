﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for exam
/// </summary>
public class clsexam
{
    public String roll
    {
        get;
        set;
    }
    public String department
    {
        get;
        set;
    }
    public String semester
    {
        get;
        set;
    }
    public String subjectcode
    {
        get;
        set;
    }
    public String subject
    {
        get;
        set;
    }
    public String t_id
    {
        get;
        set;
    }
    public String questionset
    {
        get;
        set;
    }
    public String answerpaper
    {
        get;
        set;
    }
    public String marks
    {
        get;
        set;
    }
    public String year
    {
        get;
        set;
    }
    public String up_id
    {
        get;
        set;
    }
    public String submittime
    {
        get;
        set;
    }
    public DataSet retriveexamheader()
    {
        DataSet dss = server.getAllData("select * from examschedule where Id=" + Int32.Parse(up_id) + "");
        return dss;
    }
    public DataTable retrivequestionpaper()
    {
        DataTable dt = new DataTable();
        DataRow dr;
        
        dt.Columns.Add("sl_no");
        dt.Columns.Add("question");
        dt.Columns.Add("marks");
        dt.Columns.Add("option1");
        dt.Columns.Add("option2");
        dt.Columns.Add("option3");
        dt.Columns.Add("option4");
        dt.Columns.Add("correctanswer");
        cls_teacher obj = new cls_teacher();
        obj.department = department;
        obj.semester = semester;
        obj.subject_code = subjectcode;
        obj.year = year;
        int course_id = obj.retrivecourseid();
        DataSet dss = server.getAllData("select * from examschedule where Id=" + Int32.Parse(up_id) + "");
        
        string qset = dss.Tables[0].Rows[0]["questionset"].ToString();
        DataSet ds = server.getAllData("select * from examquestion where course_id=" + course_id + " and t_id='" + t_id + "' and question_set='" + qset + "'");
        int flag = ds.Tables[0].Rows.Count;
        List<string> qlist = new List<string>();

        foreach (DataRow row in ds.Tables[0].Rows)
        {
            string q=row["question"].ToString();
            string mrks = row["marks"].ToString();
            string op1 = row["option1"].ToString();
            string op2 = row["option2"].ToString();
            string op3 = row["option3"].ToString();
            string op4 = row["option4"].ToString();
            string cans = row["correctanswer"].ToString();
            qlist.Add(q + "#" + mrks + "#" + op1 + "#" + op2 + "#" + op3 + "#" + op4 + "#" + cans);
        }
        string[] qarray = qlist.ToArray();
        string[] newqarray = server.shuffle(qarray);
        int flag2 = newqarray.Length;
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            dr["sl_no"] = i + 1;
            dr["question"] = newqarray[i].Split('#')[0].ToString();
            dr["marks"] = newqarray[i].Split('#')[1].ToString();

            string op1 = newqarray[i].Split('#')[2].ToString();
            string op2 = newqarray[i].Split('#')[3].ToString();
            string op3 = newqarray[i].Split('#')[4].ToString();
            string op4 = newqarray[i].Split('#')[5].ToString();
            string[] options = { op1,op2,op3,op4 };
            string[] shuffle = server.shuffle(options);
            dr["option1"] = shuffle[0].ToString();
            dr["option2"] = shuffle[1].ToString();
            dr["option3"] = shuffle[2].ToString();
            dr["option4"] = shuffle[3].ToString();
            dr["correctanswer"] = newqarray[i].Split('#')[6].ToString();
            dt.Rows.Add(dr);

        }
        return dt;
    }

    public DataTable retriveanswerpaper()
    {
        DataTable dt = new DataTable();
        DataRow dr;

        dt.Columns.Add("sl_no");
        dt.Columns.Add("question");
        dt.Columns.Add("marks");
        dt.Columns.Add("option1");
        dt.Columns.Add("option2");
        dt.Columns.Add("option3");
        dt.Columns.Add("option4");
        dt.Columns.Add("correctanswer");


        DataSet ds = server.getAllData("select * from examquestion where year='" + year + "' and department='" + department + "' and semester='" + semester + "' and subjectcode='" + subjectcode + "'");

        List<string> qlist = new List<string>();

        foreach (DataRow row in ds.Tables[0].Rows)
        {
            string q = row["question"].ToString();
            string mrks = row["marks"].ToString();
            string op1 = row["option1"].ToString();
            string op2 = row["option2"].ToString();
            string op3 = row["option3"].ToString();
            string op4 = row["option4"].ToString();
            string cans = row["correctanswer"].ToString();
            qlist.Add(q + "#" + mrks + "#" + op1 + "#" + op2 + "#" + op3 + "#" + op4 + "#" + cans);
        }
        string[] qarray = qlist.ToArray();
        string[] newqarray = server.shuffle(qarray);
        int flag = newqarray.Length;
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            dr["sl_no"] = i + 1;
            dr["question"] = newqarray[i].Split('#')[0].ToString();
            dr["marks"] = newqarray[i].Split('#')[1].ToString();

            string op1 = newqarray[i].Split('#')[2].ToString();
            string op2 = newqarray[i].Split('#')[3].ToString();
            string op3 = newqarray[i].Split('#')[4].ToString();
            string op4 = newqarray[i].Split('#')[5].ToString();
            string[] options = { op1, op2, op3, op4 };
            string[] shuffle = server.shuffle(options);
            dr["option1"] = shuffle[0].ToString();
            dr["option2"] = shuffle[1].ToString();
            dr["option3"] = shuffle[2].ToString();
            dr["option4"] = shuffle[3].ToString();
            dr["correctanswer"] = newqarray[i].Split('#')[6].ToString();
            dt.Rows.Add(dr);

        }
        return dt;
    }
    private string gettchename(string id)
    {
        DataSet tr = server.getAllData("select name from teacher where t_id='" + id + "'");
        return tr.Tables[0].Rows[0]["name"].ToString();
    }
    public DataTable schedule()
    {
        string ampm = null;
        DataTable dt = new DataTable();
        DataRow dr;

        dt.Columns.Add("sl_no");
       // dt.Columns.Add("department");
        dt.Columns.Add("upid");
        dt.Columns.Add("subjectcode");
        dt.Columns.Add("teacher");
        dt.Columns.Add("questionset");
        dt.Columns.Add("questionheader");
        dt.Columns.Add("date");
        dt.Columns.Add("time");
        dt.Columns.Add("duration");
        
        DataSet ds = server.getAllData("SELECT course_details.subject_code, examschedule.Id, examschedule.questionset, examschedule.t_id, examschedule.questionheader, examschedule.date, examschedule.time, examschedule.duration FROM course_details INNER JOIN examschedule ON course_details.course_id = examschedule.course_id where department='" + department + "' and semester='" + semester + "' and year=" + Int32.Parse(year) + " ORDER BY examschedule.date, examschedule.time");
        int flag = ds.Tables[0].Rows.Count;
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            dr["sl_no"] = i + 1;
           // dr["department"] = ds.Tables[0].Rows[i]["department"].ToString();
            dr["upid"] = ds.Tables[0].Rows[i]["Id"].ToString();
            dr["subjectcode"] = ds.Tables[0].Rows[i]["subject_code"].ToString();
            string t_id = ds.Tables[0].Rows[i]["t_id"].ToString();
            string name = gettchename(t_id);
            dr["teacher"] = name + "-(" + t_id + ")";
            dr["questionset"] = ds.Tables[0].Rows[i]["questionset"].ToString();
            dr["questionheader"] = ds.Tables[0].Rows[i]["questionheader"].ToString();
            string date = ds.Tables[0].Rows[i]["date"].ToString();
            dr["date"] = date.Split(' ')[0].ToString();
            string time = ds.Tables[0].Rows[i]["time"].ToString();
            int hh = int.Parse(time.Split(':')[0]);
            if (hh > 12)
            {
                ampm = "PM";
            }
            else
            {
                ampm = "AM";
            }
            dr["time"] = time + " " + ampm;
            dr["duration"] = ds.Tables[0].Rows[i]["duration"].ToString();
            dt.Rows.Add(dr);
        }
        return dt;
    }
    /*
    public DataTable exampaper()
    {
        string ampm = null;
        DataTable dt = new DataTable();
        DataRow dr;

        dt.Columns.Add("sl_no");
        dt.Columns.Add("department");
        dt.Columns.Add("semester");
        dt.Columns.Add("subjectcode");
        dt.Columns.Add("teacher");
        dt.Columns.Add("questionset");
        dt.Columns.Add("questionheader");
        dt.Columns.Add("date");
        dt.Columns.Add("time");
        dt.Columns.Add("duration");
        DataSet ds = server.getAllData("select * from examschedule where year='"+year+"' and department='" + department + "' and semester='" + semester + "' and subjectcode='" + subjectcode + "'order by date,time");
        int flag = ds.Tables[0].Rows.Count;
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            dr["sl_no"] = i + 1;
            dr["department"] = ds.Tables[0].Rows[i]["department"].ToString();
            dr["semester"] = ds.Tables[0].Rows[i]["semester"].ToString();
            dr["subjectcode"] = ds.Tables[0].Rows[i]["subjectcode"].ToString();
            dr["teacher"] = ds.Tables[0].Rows[i]["teacher"].ToString();
            dr["questionset"] = ds.Tables[0].Rows[i]["questionset"].ToString();
            dr["questionheader"] = ds.Tables[0].Rows[i]["questionheader"].ToString();
            string date = ds.Tables[0].Rows[i]["date"].ToString();
            dr["date"] = date.Split(' ')[0].ToString();
            string time = ds.Tables[0].Rows[i]["time"].ToString();
            int hh = int.Parse(time.Split(':')[0]);
            if (hh > 12)
            {
                ampm = "PM";
            }
            else
            {
                ampm = "AM";
            }
            dr["time"] = time + " " + ampm;
            dr["duration"] = ds.Tables[0].Rows[i]["duration"].ToString();
            dt.Rows.Add(dr);
        }
        return dt;
    }
    */
    public int uploadanswerscript()
    {
        int result = server.InsertUpdateDelete("insert into answerscript values(" + roll + "," + up_id + ",'" + submittime + "','" + answerpaper + "'," + marks + ")");
        return result;
    }
    public int checkanswerscript()
    {
        string query = "select * from answerscript where roll=" + roll + " and Id=" + up_id + "";
        DataSet ds = server.getAllData(query);
        int flag = ds.Tables[0].Rows.Count;
        if(flag==0)
        {
            return 0;
        }
        string script = ds.Tables[0].Rows[0]["answerscript_id"].ToString();
        return Int32.Parse(script);
    }
}