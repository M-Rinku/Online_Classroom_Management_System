﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.IO;
using System.Net.NetworkInformation;

/// <summary>
/// Summary description for server
/// </summary>
public class server
{
    private static string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["ocsimsConnectionString"].ConnectionString.ToString();
    public static SqlConnection mycon()
    {
        SqlConnection con = new SqlConnection(connectionstring);
        return con;
    }
    public static int InsertUpdateDelete(String query)
    {
        SqlConnection con = mycon();
        con.Open();
        SqlCommand com = new SqlCommand(query, con);
        int result = com.ExecuteNonQuery();
        con.Close();
        return result;
    }
    public static DataTable gvbind(String query)
    {
        SqlConnection con = mycon();
        con.Open();
        SqlCommand com = new SqlCommand(query, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;

    }
    public static Boolean CheckDupliacte(String query)
    {
        Boolean flag = false;
        SqlConnection con = mycon();
        con.Open();
        SqlCommand com = new SqlCommand(query, con);
        SqlDataReader dr = com.ExecuteReader();
        if (dr.Read())
        {
            flag = true;
        }
        dr.Close();
        con.Close();
        return flag;
    }
    public static DataSet getAllData(String query)
    {
        // Boolean flag = false;
        SqlConnection con = mycon();
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;

    }
    public static string GetIPAddress()
    {
        String address = "";
        WebRequest request = WebRequest.Create("http://checkip.dyndns.org/");
        using (WebResponse response = request.GetResponse())
        using (StreamReader stream = new StreamReader(response.GetResponseStream()))
        {
            address = stream.ReadToEnd();
        }

        int first = address.IndexOf("Address: ") + 9;
        int last = address.LastIndexOf("</body>");
        address = address.Substring(first, last - first);

        return address;
    }
    public static string GetMACAddress()
    {
        string macAddresses = "";

        foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
            {
                macAddresses += nic.GetPhysicalAddress().ToString();
                break;
            }
        }
        return macAddresses;
    
}
    public static string[] shuffle(string[] option)
    {
        List<string> list = new List<string>();
        string[] options = option;
        var newlist = new List<string>(options);
        int flag = options.Length;
        int p = options.Length;
        for (int i = 0; list.Count != flag; i++)
        {
            Random rand = new Random();
            string aa = options[rand.Next(p)];
            if (list.Contains(aa))
            {

                newlist.Remove(aa);
                options = newlist.ToArray();
                p = options.Length;
            }
            else
            {
                list.Add(aa);
            }
        }
        string[] shuffle = list.ToArray();
        return shuffle;
    }

}