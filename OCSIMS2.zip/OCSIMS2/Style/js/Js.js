﻿
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function myFunction() {
    if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
    } else {
        navbar.classList.remove("sticky");
    }
}
function myFunction2() {
    if (window.pageYOffset >= sticky) {
        
    } else {
        content.classList.remove("sticky");
    }
}
function display_c() {
    var refresh = 1000; // Refresh rate in milli seconds
    mytime = setTimeout('display_ct()', refresh)
}

function display_ct() {
    var strcount
    var x = new Date()
    var date = x.getDate();
    
    var year = x.getFullYear();
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const d = new Date();
    let day = days[d.getDay()];
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = months[d.getMonth()];
    var hours = d.getHours();
    var minutes = d.getMinutes();
    var seconds = d.getSeconds();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours < 10 ? '0' + hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    var strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
    document.getElementById('timenow').textContent = day+" "+date+" "+month+" "+year+" "+strTime;
    tt = display_c();
}
function doClick(imgbtn_login, e)
{
    var key;
    if (window.event)
        key = window.event.keyCode;
    else
        key = e.which;
    if (key == 13)
    {
        var btn = document.getElementById(imgbtn_login);
        if (btn != null)
        {
            btn.click();
            event.keyCode = 0;
        }
    }
}



