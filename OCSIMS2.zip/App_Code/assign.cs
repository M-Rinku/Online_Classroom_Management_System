﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for assign
/// </summary>
public class assign
{
    public String assignment_id
    {
        get;
        set;
    }
    public String roll
    {
        get;
        set;
    }
    public String stream
    {
        get;
        set;
    }
    public String semester
    {
        get;
        set;
    }
    public String subjectcode
    {
        get;
        set;
    }
    public String submissionaction
    {
        get;
        set;
    }
    public String subject
    {
        get;
        set;
    }
    public String fromdate
    {
        get;
        set;
    }
    public String todate
    {
        get;
        set;
    }
    public String questionfilepath
    {
        get;
        set;
    }
    public String answerfilepath
    {
        get;
        set;
    }
    public String title
    {
        get;
        set;
    }
    public String year
    {
        get;
        set;
    }
    public String ansscript
    {
        get;
        set;
    
    }
    public String t_id
    {
        get;
        set;
    }
    public String marks
    {
        get;
        set;
    }
    public String datetime
    {
        get;
        set;
    }
    public String ip_address
    {
        get;
        set;
    }
    public DataTable retrivesemester()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("Semester");
        DataSet ds = server.getAllData("select semester from assignment where year='" + year + "' and stream='" + stream + "'");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["Semester"] = "Select";
        dt.Rows.Add(dr);
        // Creating an List<T> of string
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["semester"].ToString();
            if (list.Contains("'" + val + "'"))
            {

            }
            else
            {
                list.Add("'" + ds.Tables[0].Rows[i]["semester"].ToString() + "'");
                dr["Semester"] = ds.Tables[0].Rows[i]["semester"].ToString();
                dt.Rows.Add(dr);
            }

        }
        return dt;

    }
    public DataTable retrivesubject()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("Subject");
        DataSet ds = server.getAllData("select * from assignment where year='" + year + "' and stream='" + stream + "' and semester='" + semester + "'");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["Subject"] = "Select";
        dt.Rows.Add(dr);
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["subjectcode"].ToString();
            if (list.Contains("'" + val + "'"))
            {
                //if yes
            }
            else
            {
                //if no
                string code = ds.Tables[0].Rows[i]["subjectcode"].ToString();
                list.Add("'" + ds.Tables[0].Rows[i]["subjectcode"].ToString() + "'");
                dr["Subject"] = "(" + code + ")_" + ds.Tables[0].Rows[i]["subject"].ToString();
                dt.Rows.Add(dr);
            }
        }
        return dt;
    }
    public DataTable retriveassignment()
    {
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("assign_id");
        dt.Columns.Add("Sl.No.");
        dt.Columns.Add("Code");
        dt.Columns.Add("Title");
        dt.Columns.Add("link");
        dt.Columns.Add("Assignment Given Date");
        dt.Columns.Add("Submission Date");
        dt.Columns.Add("Answer");

        DataSet ds = server.getAllData("SELECT assignment.t_id, assignment.title, assignment.fromdate, assignment.todate, assignment.questionfilepath, course_details.subject, course_details.subject_code, assignment.assignment_id, teacher.name FROM assignment INNER JOIN course_details ON assignment.course_id = course_details.course_id INNER JOIN teacher ON assignment.t_id = teacher.t_id WHERE (course_details.year = "+Int32.Parse(year)+") AND (course_details.department = '"+stream+"') AND (course_details.semester = "+Int32.Parse(semester)+")");
        int flag = ds.Tables[0].Rows.Count;
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            dr["assign_id"] = ds.Tables[0].Rows[i]["assignment_id"].ToString();
            dr["Sl.No."] = i + 1;
            dr["Code"] = ds.Tables[0].Rows[i]["subject_code"].ToString();
            dr["Title"] = ds.Tables[0].Rows[i]["title"].ToString();
            dr["link"] = ds.Tables[0].Rows[i]["questionfilepath"].ToString();
            dr["Assignment Given Date"] = ds.Tables[0].Rows[i]["fromdate"].ToString();
            dr["Submission Date"] = ds.Tables[0].Rows[i]["todate"].ToString();
            dt.Rows.Add(dr);
        }
        return dt;
    }
    public string assignment_deadline()
    {
        DataSet ds = server.getAllData("select * from assignment where assignment_id='" + assignment_id + "'");
        return ds.Tables[0].Rows[0]["todate"].ToString();
    }
    public string check_assignment()
    {
        bool flag = server.CheckDupliacte("select * from assignmentans where assignment_id='" + assignment_id + "' and roll='" + roll + "'");
        if (flag == false)
        {
            return "0";
        }
        else
        {
            DataSet result = server.getAllData("select script_id from assignmentans where assignment_id='" + assignment_id + "' and roll='" + roll + "'");
            string id = result.Tables[0].Rows[0]["script_id"].ToString();
            return id;
        }
    }
    public string retriveaction()
    {


        DataSet ds = server.getAllData("select * from assignmentans where script_id='" + ansscript + "'");
        string res = ds.Tables[0].Rows[0]["submission_action"].ToString();
        return res;
    }
    public int update_assign_answer_path()
    {
        int result = server.InsertUpdateDelete("update assignmentans set answerfilepath='" + answerfilepath + "', upload_datetime='" + datetime + "', ip_address='" + ip_address + "' where script_id='" + ansscript + "'");
        if (result == 0)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }


    public DataSet retriveassignmentdetails()
    {

        DataSet ds = server.getAllData("select * from assignment where assignment_id='" + assignment_id + "'");

        return ds;
    }
    public String insert_assign_answer_path()
    {
        bool flag = server.CheckDupliacte("select * from assignmentans where assignment_id='" + assignment_id + "' and roll='" + roll + "'");
        if (flag == false)
        {
            int result = server.InsertUpdateDelete("insert into assignmentans values(" + roll + "," + assignment_id + ",'" + answerfilepath + "','" + submissionaction + "','" + marks + "','" + datetime + "','" + ip_address + "')");
            if (result == 0)
            {
                return "0";
            }
            else
            {
                return roll;
            }
        }
        else
        {
            return "9";
        }
    }
    public string retriveansfilepath()
    {
        DataSet ds = server.getAllData("select * from assignmentans where script_id='" + ansscript + "'");
        return ds.Tables[0].Rows[0]["answerfilepath"].ToString();
    }
    public void update_action()
    {
        int result = server.InsertUpdateDelete("update assignmentans set submission_action='" + submissionaction + "' where script_id='" + ansscript + "'");
    }

   
}