﻿ using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for cls_teacher
/// </summary>
public class cls_teacher
{
    string msg = null;
    public string id
    {
        get;
        set;
    }
    public string department
    {
        get;
        set;
    }
    public string semester
    {
        get;
        set;
    }
    public string subject
    {
        get;
        set;
    }
    public string subject_code
    {
        get;
        set;
    }
    public string question_set
    {
        get;
        set;
    }
    public string teacher
    {
        get;
        set;
    }
    public string question
    {
        get;
        set;
    }
    public string opt_a
    {
        get;
        set;
    }
    public string opt_b
    {
        get;
        set;
    }
    public string opt_c
    {
        get;
        set;
    }
    public string opt_d
    {
        get;
        set;
    }
    public string correct_answer
    {
        get;
        set;
    }
    public string marks
    {
        get;
        set;
    }
    public string questionheader
    {
        get;
        set;
    }
    public string date
    { 
        get;
        set;
    }
    public string time
    {
        get;
        set;
    }
    public string duration
    {
        get;
        set;
    }
    public string fromdate
    {
        get;
        set;
    }
    public string todate
    {
        get;
        set;
    }
    public string questionfilepath
    {
        get;
        set;
    }
    public string submission_action
    {
        get;
        set;
    }
    public string title
    {
        get;
        set;
    }
    public string year
    {
        get;
        set;
    }
    public DataSet getteacherdetail()
    {
        DataSet ds = server.getAllData("select * from teacher where t_id='" + id + "'");
        return ds;
    }
    public int  uploadassignment()
    {
        int course_id = retrivecourseid();
        string query = "insert into assignment values(" + course_id + "," + id + ",'" + title + "','" + fromdate + "','" + todate + "','" + questionfilepath + "','" + marks + "')";
        int result = server.InsertUpdateDelete(query);
        if (result != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int add_question()
    {
        string query = "insert into  examquestion values(" + Int32.Parse(id) + ",'" + question_set + "','" + teacher + "','" + question + "','" + opt_a + "','" + opt_b + "','" + opt_c + "','" + opt_d + "','" + correct_answer + "','" + marks + "')";
        int result = server.InsertUpdateDelete(query);
        if (result != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int delete_question()
    {
        string query = "delete from examquestion where Id='"+id+"'";
        int result = server.InsertUpdateDelete(query);
        if (result != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int update_question()
    {
        string query = "update examquestion set ";
        if (question_set!=null)
        {
            query = query + "question_set='" + question_set + "', ";
        }
         if(question!=null)
        {
            query = query + "question='" + question + "', ";
        }
         if(opt_a!=null)
        {
            query = query + "option1='" + opt_a + "', ";
        }
         if(opt_b!=null)
        {
            query = query + "option2='" + opt_b + "', ";
        }
         if(opt_c!=null)
        {
            query = query + "option3='" + opt_c + "', ";
        }
         if(opt_d!=null)
        {
            query = query + "option4='" + opt_d + "', ";
        }
        if (correct_answer != null)
        {
            query = query + "correctanswer='" + correct_answer + "', ";
        }
        if (marks != null)
        {
            query = query + "marks='" + marks + "' ";
        }
        query = query + "where Id=" + id + "";
        int result = server.InsertUpdateDelete(query);
        if (result != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int add_schedule()
    {
        string queryy = "insert into examschedule values('"+department+"','"+semester+"','"+subject_code+"','"+teacher+"','"+question_set+"','"+questionheader+"','"+date+"','"+time+"','"+duration+"')";
        int resultt = server.InsertUpdateDelete(queryy);
        if (resultt != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    /*
    public DataTable retriveyear()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("department");
        DataSet ds = server.getAllData("select department from coursedetails ");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["department"] = "Select";
        dt.Rows.Add(dr);
        // Creating an List<T> of string
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["department"].ToString();
            if (list.Contains("'" + val + "'"))
            {

            }
            else
            {
                list.Add("'" + ds.Tables[0].Rows[i]["department"].ToString() + "'");
                dr["department"] = ds.Tables[0].Rows[i]["department"].ToString();
                dt.Rows.Add(dr);
            }

        }
        return dt;

    }*/

    public DataTable retrivedepartment()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("department");
        DataSet ds = server.getAllData("select department from course_details where year=" + Int32.Parse(year) + "");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["department"] = "Select";
        dt.Rows.Add(dr);
        // Creating an List<T> of string
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["department"].ToString();
            if (list.Contains("'" + val + "'"))
            {

            }
            else
            {
                list.Add("'" + ds.Tables[0].Rows[i]["department"].ToString() + "'");
                dr["department"] = ds.Tables[0].Rows[i]["department"].ToString();
                dt.Rows.Add(dr);
            }

        }
        return dt;

    }

    public DataTable retrivesemester()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("Semester");
        DataSet ds = server.getAllData("select semester from course_details where department='" + department + "' and year="+Int32.Parse(year)+" order by semester ASC");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["Semester"] = "Select";
        dt.Rows.Add(dr);
        // Creating an List<T> of string
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["semester"].ToString();
            if (list.Contains("'" + val + "'"))
            {

            }
            else
            {
                list.Add("'" + ds.Tables[0].Rows[i]["semester"].ToString() + "'");
                dr["Semester"] = ds.Tables[0].Rows[i]["semester"].ToString();
                dt.Rows.Add(dr);
            }

        }
        return dt;

    }
    public DataTable retrivesubject()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("Subject");
        DataSet ds = server.getAllData("select * from course_details where department='" + department + "' and semester='" + semester + "' and year=" + Int32.Parse(year) + "");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["Subject"] = "Select";
        dt.Rows.Add(dr);
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["subject_code"].ToString();
            if (list.Contains("'" + val + "'"))
            {
                //if yes
            }
            else
            {
                //if no
                string code = ds.Tables[0].Rows[i]["subject_code"].ToString();
                list.Add("'" + ds.Tables[0].Rows[i]["subject_code"].ToString() + "'");
                dr["Subject"] = "(" + code + ")_" + ds.Tables[0].Rows[i]["subject"].ToString();
                dt.Rows.Add(dr);
            }
        }
        return dt;
    }
    public DataTable retrivesubjectwithoutcode()
    {
        string val = null;
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("Subject");
        DataSet ds = server.getAllData("select * from course_details");
        int flag = ds.Tables[0].Rows.Count;
        dr = dt.NewRow();
        dr["Subject"] = "Select";
        dt.Rows.Add(dr);
        List<string> list = new List<string>();
        for (int i = 0; i < flag; i++)
        {
            dr = dt.NewRow();
            val = ds.Tables[0].Rows[i]["subject"].ToString();
            if (list.Contains("'" + val + "'"))
            {
                //if yes
            }
            else
            {
                //if no
                string code = ds.Tables[0].Rows[i]["subject"].ToString();
                list.Add("'" + ds.Tables[0].Rows[i]["subject"].ToString() + "'");
                dr["Subject"] = ds.Tables[0].Rows[i]["subject"].ToString();
                dt.Rows.Add(dr);
            }
        }
        return dt;
    }
    public DataTable gvbindingforquestion()
    {
        string query = "SELECT examquestion.Id, examquestion.question_set, examquestion.question, examquestion.option1, examquestion.option2, examquestion.option3, examquestion.option4, examquestion.correctanswer, examquestion.marks FROM course_details INNER JOIN examquestion ON course_details.course_id = examquestion.course_id INNER JOIN teacher ON examquestion.t_id = teacher.t_id WHERE (course_details.year = '" + year + "') AND (course_details.department = '" + department + "') AND (course_details.semester = " + Int32.Parse(semester) + ") AND (course_details.subject_code = '" + subject_code + "')";
        DataTable res = server.gvbind(query);
        return res;
    }
     public string showassignment(int value)
    {
        string query = "SELECT assignmentans.script_id, assignmentans.roll, assignmentans.upload_datetime, assignmentans.ip_address, assignmentans.answerfilepath, assignment.marks FROM assignment INNER JOIN course_details ON assignment.course_id = course_details.course_id INNER JOIN teacher ON assignment.t_id = teacher.t_id INNER JOIN assignmentans ON assignment.assignment_id = assignmentans.assignment_id WHERE (course_details.year = '" + year + "') AND (course_details.department = '" + department + "') AND (course_details.semester = " + Int32.Parse(semester) + ") AND (course_details.subject_code = '" + subject_code + "') AND (teacher.t_id = "+Int32.Parse(id)+")";
        DataSet ds = server.getAllData(query);

       // DataSet ds = server.getAllData("select * from assignmentans where year='" + year + "' and stream='" + department + "' and semester='" + semester + "' and t_id=" + id + " and submission_action='0,1,1' order by roll ");
        int count = ds.Tables[0].Rows.Count;
        if(count<=value)
        {
            return "0";
        }
        string script = ds.Tables[0].Rows[value]["script_id"].ToString();
        DataSet dss = server.getAllData("select marks from assignmentans where script_id=" + script + "");
        string obtnmrks = dss.Tables[0].Rows[0]["marks"].ToString();
        string path=ds.Tables[0].Rows[value]["answerfilepath"].ToString();
        string roll = ds.Tables[0].Rows[value]["roll"].ToString();
        string marks = ds.Tables[0].Rows[value]["marks"].ToString();
        string date = ds.Tables[0].Rows[value]["upload_datetime"].ToString();
        string ip = ds.Tables[0].Rows[value]["ip_address"].ToString();
        return script + "#" + roll + "#" + path + "#" + marks + "#" + date + "#" + ip + "#" + obtnmrks;
    }
    public int uploadmarks()
    {
        int result = server.InsertUpdateDelete("update assignmentans set marks='" + marks + "', submission_action='" + submission_action + "' where script_id='" + id + "'");
        if (result != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }


    }
    public int retrivecourseid()
    {
        
        DataSet ds = server.getAllData("select course_id from course_details where department='" + department + "' and semester='" + semester + "' and year=" + Int32.Parse(year) + " and subject_code='" + subject_code + "'");

        int val = Int32.Parse(ds.Tables[0].Rows[0]["course_id"].ToString());
            
        return val;
    }
}