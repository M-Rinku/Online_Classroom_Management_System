﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for student
/// </summary>
public class student
{
    public String roll
    {
        get;
        set;
    }
    public String password
    {
        get;
        set;
    }
    public String tbl
    {
        get;
        set;
    }
    public String id_name
    {
        get;
        set;
    }
    public DataSet getallstddetail()
    {
        DataSet ds = server.getAllData("select * from student where roll='" + roll + "'");
        return ds;
    }

}