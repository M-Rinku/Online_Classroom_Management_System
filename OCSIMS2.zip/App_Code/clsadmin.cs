﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsadmin
/// </summary>
public class clsadmin
{
    public String id
    {
        get;
        set;
    }
    public String password
    {
        get;
        set;
    }
    public String tbl
    {
        get;
        set;
    }
    public String id_name
    {
        get;
        set;
    }
    public String s_id
    {
        get;
        set;
    }
    public String t_id
    {
        get;
        set;
    }
    public String name
    {
        get;
        set;
    }
    public String roll
    {
        get;
        set;
    }
    public String email
    {
        get;
        set;
    }
    public String mob_no
    {
        get;
        set;
    }
    public String address
    {
        get;
        set;
    }
    public String department
    {
        get;
        set;
    }
    public String semester
    {
        get;
        set;
    }
    public String year
    {
        get;
        set;
    }
    public String profilepicture
    {
        get;
        set;
    }
    public String registration_no
    {
        get;
        set;
    }
    public String subject
    {
        get;
        set;
    }

    public DataSet getalladmindetail()
    {
        DataSet ds = server.getAllData("select * from admin where admin_id='" + id + "'");
        return ds;
    }
    public string insertstudent()
    {
        bool flag = server.CheckDupliacte("select * from student where roll='" + roll + "'");
        if(flag==false)
        {
            int result = server.InsertUpdateDelete("insert into student values("+roll+",'" + password + "','" + name + "','" + email + "','" + mob_no + "','" + address + "','" + department + "','" + semester + "','" + year + "','" + profilepicture + "')");
            if(result==0)
            {
                return "0";
            }
            else
            {
                DataSet ds = server.getAllData("select * from student where roll='" + roll + "'");
                string id = ds.Tables[0].Rows[0]["roll"].ToString();
                return id;
            }
        }
        else
        {
            return "9";
        }
    }

    public string insertteacher()
    {
        bool flag = server.CheckDupliacte("select * from teacher where registration_no='" + registration_no + "'");
        if (flag == false)
        {
            int result = server.InsertUpdateDelete("insert into teacher values('" + password + "','" + name + "','" + registration_no + "','" + subject + "','" + email + "','" + mob_no + "','" + profilepicture + "')");
            if (result == 0)
            {
                return "0";
            }
            else
            {
                DataSet ds = server.getAllData("select t_id from teacher where registration_no='" + registration_no + "'");
                string id = ds.Tables[0].Rows[0]["t_id"].ToString();
                return id;
            }
        }
        else
        {
            return "9";
        }
    }
}