﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for login
/// </summary>
public class clslogin
{
    public String id
    {
        get;
        set;
    }
    public String password
    {
        get;
        set;
    }
    public String tablename
    {
        get;
        set;
    }
    public String idname
    {
        get;
        set;
    }
    public String path
    {
        get;
        set;
    }
    public int login()
    {
        Boolean flag = server.CheckDupliacte("select * from "+tablename+" where "+idname+"='" + id + "' and password='" + password + "'");
        if(flag==true)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public string getmobile()
    {
        DataSet ds = server.getAllData("select * from "+tablename+" where "+idname+"=" + id + "");
        string mob = ds.Tables[0].Rows[0]["mob_no"].ToString();
        string name = ds.Tables[0].Rows[0]["name"].ToString();
        string startmob = mob.Substring(0, 3);
        string endmob = mob.Substring(mob.Length-3,3);
        return mob + "/" + startmob + "****" + endmob + "/" + name;
    }
    public int changepass()
    {
        int res = server.InsertUpdateDelete("update " + tablename + " set password='" + password + "' where " + idname + "=" + id + "");
        if (res !=0 )
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int changepic()
    {
        int res = server.InsertUpdateDelete("update " + tablename + " set profilepicture='" + path + "' where " + idname + "=" + id + "");
        if (res != 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}